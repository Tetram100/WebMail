function reset_form() {
	document.getElementById('from').value = "";
	document.getElementById('to').value = "";
	document.getElementById('sending_time').value = "";
	document.getElementById('server').value = "";
	document.getElementById('subject').value = "";
	document.getElementById('message').value = "";
}